package com.introtoandroid.eilers_hannah_lab4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Html;
import android.view.Menu;
import android.view.MenuInflater;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView greeting_italic = findViewById(R.id.greeting_italic);

        String string = "Hello, my name is" + "<b><i>" + " Hannah Eilers"+ "</b></i>" + ".";
        greeting_italic.setText(Html.fromHtml(string));

        //String greeting_regular;
        //greeting_regular = getResources().getString(R.string.greeting);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
        //getMenuInflater().inflate(R.menu.menu, menu);
        //return true;
    }
}
