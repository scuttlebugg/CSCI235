package com.introtoandroid.eilers_hannah_lab5a;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.content.Intent;
import android.view.View;


public class MainActivity extends AppCompatActivity {

    Spinner userStateSelect;
    Button buttonSubmit;
    EditText userBirthdayEntry, userEmailEntry, favWebsiteEntry, userNameEntry;
    RadioGroup userGenderSelect;

    String stringName1, stringState, stringEmail1, stringWebsite1, stringBday, stringGender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonSubmit = (Button) findViewById(R.id.btnSubmit);
        userNameEntry = findViewById(R.id.userNameEditText);
        userEmailEntry = findViewById(R.id.userEmailEditText);
        favWebsiteEntry = findViewById(R.id.favWebsiteEditText);

        //userStateSelect = findViewById(R.id.userStateSelect);
        //userBirthdayEntry = findViewById(R.id.userBirthdayEntry);
        //userGenderSelect = findViewById(R.id. userGenderSelect);

        /*
        stringState = userStateSelect.toString();
        stringBday = userBirthdayEntry.toString();
        stringGender = userGenderSelect.toString();
        */
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, activity2.class);

                stringName1 = userNameEntry.getText().toString();
                stringEmail1 = userEmailEntry.getText().toString();
                stringWebsite1 = favWebsiteEntry.getText().toString();

                intent.putExtra("Name", stringName1);
                intent.putExtra("Site", stringWebsite1);
                intent.putExtra("Email", stringEmail1);

                /*
                intent.putExtra("State", stringState);
                intent.putExtra("BDay", stringBday);
                intent.putExtra("Gender", stringGender);
                */

                startActivity(intent);
            }
        });
    }
}

