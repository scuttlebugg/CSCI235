package com.introtoandroid.eilers_hannah_lab5a;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.content.Intent;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    Spinner userStateSelect;
    Button buttonSubmit;
    EditText userBirthdayEntry, userEmailEntry, favWebsiteEntry, userNameEntry;
    RadioGroup userGenderSelect;
    RadioButton rbGender;

    String stringName1, stringState1, stringEmail1, stringWebsite1, stringBday1, stringGender1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonSubmit = (Button) findViewById(R.id.btnSubmit);
        userNameEntry = findViewById(R.id.userNameEditText);
        userEmailEntry = findViewById(R.id.userEmailEditText);
        favWebsiteEntry = findViewById(R.id.favWebsiteEditText);
        userBirthdayEntry = findViewById(R.id.userBirthdayEditText);
        userStateSelect = findViewById(R.id.userStateSelect);
        userGenderSelect = findViewById(R.id.userGenderSelect);

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, activity2.class);

                int radioId = userGenderSelect.getCheckedRadioButtonId();
                rbGender = findViewById(radioId);

                stringName1 = userNameEntry.getText().toString();
                stringEmail1 = userEmailEntry.getText().toString();
                stringWebsite1 = favWebsiteEntry.getText().toString();
                stringBday1 = userBirthdayEntry.getText().toString();
                stringState1 = userStateSelect.getSelectedItem().toString();
                stringGender1 = rbGender.getText().toString();

                intent.putExtra("Name", stringName1);
                intent.putExtra("Site", stringWebsite1);
                intent.putExtra("Email", stringEmail1);
                intent.putExtra("BDay", stringBday1);
                intent.putExtra("State", stringState1);
                intent.putExtra("Gender", stringGender1);

                startActivity(intent);
            }

        });
    }
}

