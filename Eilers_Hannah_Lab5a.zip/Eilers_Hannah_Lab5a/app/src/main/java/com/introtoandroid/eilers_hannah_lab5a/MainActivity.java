package com.introtoandroid.eilers_hannah_lab5a;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.content.Intent;
import android.view.View;


public class MainActivity extends AppCompatActivity {

    Spinner userStateSelect;
    Button btnSubmit;
    EditText userBirthdayEntry, userEmailEntry, favWebsiteEntry, userName;
    RadioGroup userGenderSelect;

    String stringName, stringState, stringEmail, stringWebsite, stringBday, stringGender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSubmit = (Button) findViewById(R.id.btnSubmit);

        //userStateSelect = findViewById(R.id.userStateSelect);
        //userBirthdayEntry = findViewById(R.id.userBirthdayEntry);
        //userEmailEntry = findViewById(R.id.userEmailEntry);
        //favWebsiteEntry = findViewById(R.id.favWebsiteEntry);
        userName = findViewById(R.id.userName);
        //userGenderSelect = findViewById(R.id. userGenderSelect);

        stringName = userName.getText().toString();
        /*
        stringState = userStateSelect.toString();
        stringEmail = userEmailEntry.getText().toString();
        stringWebsite = favWebsiteEntry.getText().toString();
        stringBday = userBirthdayEntry.toString();
        stringGender = userGenderSelect.toString();
        */
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, activity2.class);

                intent.putExtra("Name", stringName);
                /*
                intent.putExtra("State", stringState);
                intent.putExtra("Email", stringEmail);
                intent.putExtra("Site", stringWebsite);
                intent.putExtra("BDay", stringBday);
                intent.putExtra("Gender", stringGender);
                */

                startActivity(intent);
            }
        });
    }
}

