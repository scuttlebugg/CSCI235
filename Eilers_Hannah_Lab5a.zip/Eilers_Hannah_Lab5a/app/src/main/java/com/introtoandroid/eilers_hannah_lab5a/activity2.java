package com.introtoandroid.eilers_hannah_lab5a;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

public class activity2 extends AppCompatActivity {

        Button buttonAddContact;
        TextView viewName, viewState, viewEmail, viewWebsite, viewBday, viewGender;
        String stringName2, stringState2, stringEmail2, stringWebsite2, stringBday2, stringGender2;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_activity2);


            buttonAddContact = (Button)findViewById(R.id.btnAddContact);
            buttonAddContact.setOnClickListener(new Button.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(ContactsContract.Intents.Insert.ACTION);
                    intent.setType(ContactsContract.RawContacts.CONTENT_TYPE);

                    TextView contactName = (TextView) findViewById(R.id.viewName);
                    TextView contactEmail = (TextView) findViewById(R.id.viewEmail);

                    intent.putExtra(ContactsContract.Intents.Insert.EMAIL, contactEmail.getText())
                            .putExtra(ContactsContract.Intents.Insert.EMAIL_TYPE,
                                    ContactsContract.CommonDataKinds.Email.TYPE_WORK);

                    intent.putExtra(ContactsContract.Intents.Insert.NAME, contactName.getText());

                    startActivity(intent);
                }

            });

            viewName = (TextView) findViewById(R.id.viewName);
            viewEmail = (TextView) findViewById(R.id.viewEmail);
            viewWebsite = (TextView) findViewById(R.id.viewWebsite);
            viewBday = (TextView) findViewById(R.id.viewBday);
            viewState = (TextView) findViewById(R.id.viewState);
            viewGender = (TextView) findViewById(R.id.viewGender);

            stringName2=getIntent().getExtras().getString("Name");
            viewName.setText("Name: " + stringName2);

            stringEmail2=getIntent().getExtras().getString("Email");
            viewEmail.setText("Email: " + stringEmail2);

            stringWebsite2=getIntent().getExtras().getString("Site");
            viewWebsite.setText("Website: " + stringWebsite2);

            stringBday2=getIntent().getExtras().getString("BDay");
            viewBday.setText("Birthday: " + stringBday2);

            stringState2=getIntent().getExtras().getString("State");
            viewState.setText("State: " + stringState2);

            stringGender2=getIntent().getExtras().getString("Gender");
            viewGender.setText("Gender: " + stringGender2);


        }

}