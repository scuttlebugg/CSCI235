package com.introtoandroid.eilers_hannah_lab5a;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class activity2 extends AppCompatActivity {

        Button buttonAddContact;
        TextView viewName, viewState, viewEmail, viewWebsite, viewBday, viewGender;
        String stringName2, stringState, stringEmail2, stringWebsite2, stringBday, stringGender;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_activity2);

            viewName = (TextView) findViewById(R.id.viewName);
            viewEmail = (TextView) findViewById(R.id.viewEmail);
            viewWebsite = (TextView) findViewById(R.id.viewWebsite);

            stringName2=getIntent().getExtras().getString("Name");
            viewName.setText("Name: " + stringName2);

            stringEmail2=getIntent().getExtras().getString("Email");
            viewEmail.setText("Email: " + stringEmail2);

            stringWebsite2=getIntent().getExtras().getString("Site");
            viewWebsite.setText("Website: " + stringWebsite2);

            //these are fine, even though 2 are showing problems
            //viewState = (TextView) findViewById(R.id.viewState);
            //viewBday = (TextView) findViewById(R.id.viewBday);
            //viewGender = (TextView) findViewById(R.id.viewGender);

            //stringState=getIntent().getExtras().getString("State");
            //viewName.setText(stringState);

            //stringBday=getIntent().getExtras().getString("BDay");
            //viewName.setText(stringBday);

            //stringGender=getIntent().getExtras().getString("Gender");
            //viewName.setText(stringGender);

            buttonAddContact = (Button)findViewById(R.id.buttonAddContact);
            buttonAddContact.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent = new Intent(ContactsContract.Intents.Insert.ACTION);
                    intent.setType(ContactsContract.RawContacts.CONTENT_TYPE);

                    intent.putExtra(ContactsContract.Intents.Insert.EMAIL, stringEmail2)
                            .putExtra(ContactsContract.Intents.Insert.EMAIL_TYPE,
                                    ContactsContract.CommonDataKinds.Email.TYPE_WORK);

                    intent.putExtra(ContactsContract.Intents.Insert.EMAIL, stringEmail2)
                            .putExtra(ContactsContract.Intents.Insert.NAME, stringName2);
                }

            });

        }

    public void sendEmail(String text) {
        Uri email = Uri.parse(text);
        Intent mailIntent = new Intent(Intent.ACTION_SENDTO, email);
        startActivity(mailIntent);
    }

    public void goToSite(String text) {
        String urlText = text.substring(4);
        Intent search = new Intent(Intent.ACTION_VIEW);
        search.setData(Uri.parse(urlText));
        startActivity(search);
    }
}