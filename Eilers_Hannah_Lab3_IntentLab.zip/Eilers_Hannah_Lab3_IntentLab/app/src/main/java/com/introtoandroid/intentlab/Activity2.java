package com.introtoandroid.intentlab;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

public class Activity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        Intent intent = getIntent();
        String text = intent.getStringExtra(MainActivity.EXTRA_TEXT);

        if (text.contains("url")) {
            goToSite(text);
        } else if (text.contains("tel")) {
            makeCall(text);
        }
    }

    public void makeCall(String text) {
        Uri number = Uri.parse(text);
        Intent dial = new Intent(Intent.ACTION_DIAL, number);
        startActivity(dial);
    }

    public void goToSite(String text) {
        String urlText = text.substring(4);
        Intent search = new Intent(Intent.ACTION_VIEW);
        search.setData(Uri.parse(urlText));
        startActivity(search);
    }
}