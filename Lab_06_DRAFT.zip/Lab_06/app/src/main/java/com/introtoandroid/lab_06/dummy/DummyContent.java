package com.introtoandroid.lab_06.dummy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DummyContent {

    public static List<DummyItem> ITEMS = new ArrayList<DummyItem>();

    public static Map<String, DummyItem> ITEM_MAP = new HashMap<String, DummyItem>();

    static {

        addItem(new DummyItem("1", "Palomar College", "https://www.palomar.edu"));
        addItem(new DummyItem("2", "Miracosta College", "https://www.miracosta.edu"));
        addItem(new DummyItem("3", "Cal State San Marcos", "https://www.csusm.edu"));
        addItem(new DummyItem("4", "San Diego State", "https://www.sdsu.edu"));
        addItem(new DummyItem("5", "UC San Diego", "https://www.UCSD.edu"));
        addItem(new DummyItem("6", "University of San Diego", "https://www.sandiego.edu"));
    }

    private static void addItem(DummyItem item) {
        ITEMS.add(item);
        ITEM_MAP.put(item.id, item);
    }

    public static class DummyItem {
        public final String id;
        public String item_name;
        public String url;

        public DummyItem(String id, String item_name, String url) {
            this.id = id;
            this.item_name = item_name;
            this.url = url;
        }

        @Override
        public String toString() {
            return item_name;
        }
    }
}
