package com.introtoandroid.rockpaperscissors;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Activity2 extends AppCompatActivity {

    private TextView winLoseTextView;
    private Button rematchButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        final Intent intent = getIntent();
        String outcome = intent.getStringExtra(MainActivity.EXTRA_TEXT);

        winLoseTextView = findViewById(R.id.winLoseTextView);
        winLoseTextView.setText(outcome);

        rematchButton = findViewById(R.id.rematchButton);

        if(outcome.contentEquals("Draw! How about a Rematch?")){
            rematchButton.setVisibility(View.VISIBLE);
        } else {
            rematchButton.setVisibility(View.INVISIBLE);
        }

        rematchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Activity2.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
