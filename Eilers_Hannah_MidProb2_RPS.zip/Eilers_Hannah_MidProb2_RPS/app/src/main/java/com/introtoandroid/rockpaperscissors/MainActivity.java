package com.introtoandroid.rockpaperscissors;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_TEXT = "com.introtoandroid.rockpaperscissors.EXTRA_TEXT";

    private Button rockButton, paperButton, scissorsButton;
    private String userChoice, comChoice;

    public String outcome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rockButton = findViewById(R.id.rockButton);
        paperButton = findViewById(R.id.paperButton);
        scissorsButton = findViewById(R.id.scissorsButton);

        rockButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userChoice = "rock";
                evaluate();
                openActivity2(outcome);
            }
        });

        paperButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userChoice = "paper";
                evaluate();
                openActivity2(outcome);
            }
        });

        scissorsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userChoice = "scissors";
                evaluate();
                openActivity2(outcome);
            }
        });
    }

    public String evaluate() {
        String array[] = {"rock", "paper", "scissors"};
        Random random = new Random();
        int index = random.nextInt(array.length);
        comChoice = array[index];

        if (comChoice == userChoice) {
            outcome = "Draw! How about a Rematch?";
        }
        if ((comChoice == "rock") && (userChoice == "scissors")) {
            outcome = "Opponent rock smashes your scissors!";
        }
        if ((comChoice == "rock") && (userChoice == "paper")) {
            outcome = "Your paper smothers the opponent rock!";
        }
        if ((comChoice == "scissors") && (userChoice == "rock")) {
            outcome = "Your rock smashes the opponent's scissors!";
        }
        if ((comChoice == "scissors") && (userChoice == "paper")) {
            outcome = "Your paper is shredded by opponent's scissors!";
        }
        if ((comChoice == "paper") && (userChoice == "rock")) {
            outcome = "Your rock is smothered by opponent's paper!";
        }
        if ((comChoice == "paper") && (userChoice == "scissors")) {
            outcome = "Your scissors shred the opponent paper!";
        }
        return outcome;
    }

    public void openActivity2(String outcome) {
        Intent intent = new Intent(this, Activity2.class);
        intent.putExtra(EXTRA_TEXT, outcome);
        startActivity(intent);
    }
}
