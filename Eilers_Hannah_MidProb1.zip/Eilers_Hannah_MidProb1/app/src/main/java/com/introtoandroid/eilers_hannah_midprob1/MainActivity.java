package com.introtoandroid.eilers_hannah_midprob1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText billTotal;
    private SeekBar tipAmount;
    //private Button calculateTip; decided againt using a button
    private TextView tipTotal, tipPercentage, totalAmount;
    private int seekBarPercentValue;
    private Float billFloatTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        billTotal = findViewById(R.id.billTotalEditText);
        tipPercentage = findViewById(R.id.tipPercentageTextView);
        tipAmount = findViewById(R.id.tipAmountSeekBar);
        //calculateTip = findViewById(R.id.calculateTipButton); decided against using a button
        tipTotal = findViewById(R.id.tipTotalTextView);
        totalAmount = findViewById(R.id.totalAmountTextView);

        tipPercentage.setText(String.valueOf(tipAmount.getProgress())+ "%");
        tipAmount.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                tipPercentage.setText(String.valueOf(tipAmount.getProgress())+ "%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                seekBarPercentValue = tipAmount.getProgress();
                generateTotals();
            }
        });
/*
//decided not to use a button. Felt fancy with my auto calculate slidebar :D
        calculateTip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                generateTotals();
            }
        });
*/
}


public void generateTotals() {
        Float result;

    billFloatTotal = Float.parseFloat(billTotal.getText().toString());

    result = billFloatTotal * seekBarPercentValue/100;

    tipTotal.setText("$" + String.valueOf(String.format("%.2f", result)+ " for tip"));
    totalAmount.setText("$" + String.valueOf(String.format("%.2f", (billFloatTotal+ result))+ " total"));
    }
}