package com.introtoandroid.eilers_hannah_lab5b;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Activity2 extends AppCompatActivity {

    Button buttonSubmitExtras;

    public static final String EXTRA_TEXT = "com.introtoandroid.eilers_hannah_lab5b.EXTRA_TEXT";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        buttonSubmitExtras = (Button) findViewById(R.id.submitExtras);
        buttonSubmitExtras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openExtrasActivity();
            }
        });
        Button onwardButton = findViewById(R.id.onwardButton);
        onwardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openActivity3();
            }
        });
    }
    public void openExtrasActivity() {
        EditText editText = findViewById(R.id.editTextSubmitExtras);

        String extras = editText.getText().toString();

        Intent intent = new Intent(this, extrasActivity.class);
        intent.putExtra(EXTRA_TEXT,extras);
        startActivity(intent);
    }
    public void openActivity3() {

        Intent intent = new Intent(this, Activity3.class);
        startActivity(intent);
    }
}
