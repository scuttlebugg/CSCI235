package com.introtoandroid.eilers_hannah_lab5b;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

public class Activity3 extends AppCompatActivity {

    EditText editTextField;
    Spinner exampleSpinner;
    String fieldNotes, snakeSpinner, radioChoice;
    RadioGroup radioSelect;
    RadioButton radioButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);

        Button buttonSubmit = (Button) findViewById(R.id.btnSubmit);
        editTextField = findViewById(R.id.editTextField);
        exampleSpinner = findViewById(R.id.exampleSpinner);
        radioSelect = findViewById(R.id.radioSelect);

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Activity3.this, Activity4.class);

                int radioId = radioSelect.getCheckedRadioButtonId();
                radioButton = findViewById(radioId);

                fieldNotes = editTextField.getText().toString();
                snakeSpinner = exampleSpinner.getSelectedItem().toString();
                radioChoice = radioButton.getText().toString();


                intent.putExtra("notes", fieldNotes);
                intent.putExtra("spinner", snakeSpinner);
                intent.putExtra("radio", radioChoice);

                startActivity(intent);
            }

        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
}
