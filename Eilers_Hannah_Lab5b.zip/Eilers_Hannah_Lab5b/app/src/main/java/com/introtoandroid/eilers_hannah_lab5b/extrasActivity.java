package com.introtoandroid.eilers_hannah_lab5b;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class extrasActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_extras);

        Intent intent = getIntent();
        String extras = intent.getStringExtra(Activity2.EXTRA_TEXT);

        TextView tv = (TextView) findViewById(R.id.textView1);
        tv.setText(extras);

    }
}
