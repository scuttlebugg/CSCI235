package com.introtoandroid.eilers_hannah_lab5b;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Activity4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_4);

        TextView radioOut, spinnerOut, notesOut;
        String stringRadio, stringSpinner, stringNotes;

            notesOut = (TextView) findViewById(R.id.notesOut);
            spinnerOut = (TextView) findViewById(R.id.spinnerOut);
            radioOut = (TextView) findViewById(R.id.radioOut);

            stringNotes = getIntent().getExtras().getString("notes");
            notesOut.setText("What did you observe out there? " + stringNotes);

            stringSpinner = getIntent().getExtras().getString("spinner");
            spinnerOut.setText("How many snakes? " + stringSpinner);

            stringRadio = getIntent().getExtras().getString("radio");
            radioOut.setText("Are you sure? " + stringRadio);
        }
    }
